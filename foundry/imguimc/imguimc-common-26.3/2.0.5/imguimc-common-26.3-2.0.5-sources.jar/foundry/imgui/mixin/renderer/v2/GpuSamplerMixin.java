package foundry.imgui.mixin.renderer.v2;

//? if >=1.21.11 {

import com.mojang.renderpearl.backend.opengl.GlSampler;
import foundry.imgui.api.ImGuiSampler;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value = {
        GlSampler.class,
        //? if >=26.2 {
        com.mojang.renderpearl.backend.vulkan.VulkanGpuSampler.class
        //? }
}, remap = false)
public class GpuSamplerMixin implements ImGuiSampler {
}

//?}
